//
//  SensegoiOS.h
//  SensegoiOS
//
//  Created by Volhan Salai on 10/25/18.
//  Copyright © 2018 Sensego. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SensegoiOS.
FOUNDATION_EXPORT double SensegoiOSVersionNumber;

//! Project version string for SensegoiOS.
FOUNDATION_EXPORT const unsigned char SensegoiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SensegoiOS/PublicHeader.h>


